import 'package:flutter/material.dart';
import '../models/product_model.dart';

class SearchProvider with ChangeNotifier {
  List<ProductModel> _searchResults = [];

  List<ProductModel> get searchResults => _searchResults;

  void searchProducts(String query, List<ProductModel> allProducts) {
    _searchResults =
        allProducts
            .where(
              (product) =>
                  product.title.toLowerCase().contains(query.toLowerCase()),
            )
            .toList();
    notifyListeners();
  }
}
