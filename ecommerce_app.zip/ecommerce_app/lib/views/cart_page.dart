import 'package:flutter/material.dart';

class CartPage extends StatelessWidget {
  final List<dynamic> cartItems;

  CartPage({required this.cartItems});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Cart")),
      body:
          cartItems.isEmpty
              ? Center(child: Text("Your cart is empty"))
              : ListView.builder(
                itemCount: cartItems.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(cartItems[index]['title']),
                    subtitle: Text("\$${cartItems[index]['price']}"),
                  );
                },
              ),
    );
  }
}
